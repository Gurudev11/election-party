
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Party Page</title>
   
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .butn {
            margin-bottom: 20px;
        }
        .img-placeholder {
            display: block;
            margin-bottom: 20px;
            max-width: 150px;
        }
    </style>
</head>
<body>
  
    <div class="container mt-5">
        <h1><?php echo e(isset($partyToEdit->id) ? 'Update Party' : 'Party Registration'); ?></h1> 
        
        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php if(isset($partyToEdit->id)): ?>
            <form id="party-form" action="<?php echo e(route('party.update', $partyToEdit->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo method_field('PUT'); ?>
        <?php else: ?>
            <form id="party-form" action="<?php echo e(route('parties.save')); ?>" method="POST" enctype="multipart/form-data">
        <?php endif; ?>

            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="name">Party Name<span class="text-danger">*</span></label>
                <input type="text" class="form-control" id="name" name="name" value="<?php echo e(old('name', isset($partyToEdit->id) ? $partyToEdit->name : '')); ?>" required>
            </div>

            <div class="form-group">
                <label for="registration_date">Registration Date<span class="text-danger">*</span></label>
                <input type="date" class="form-control" id="registration_date" name="registration_date" value="<?php echo e(old('registration_date', isset($partyToEdit->id) ? $partyToEdit->registration_date : '')); ?>" required>
            </div>

            <div class="form-group">
                <label for="address1">Address Line1<span class="text-danger">*</span></label>
                <input type="text" class="form-control" id="address1" name="address1" value="<?php echo e(old('address1', isset($partyToEdit->id) ? $partyToEdit->address->address1 : '')); ?>" required>
            </div>

            <div class="form-group">
                <label for="address2">Address Line2</label>
                <input type="text" class="form-control" id="address2" name="address2" value="<?php echo e(old('address2', isset($partyToEdit->id) ? ($partyToEdit->address ? $partyToEdit->address->address2 : '') : '')); ?>">
            </div>

            <div class="form-group">
                <label for="state">State<span class="text-danger">*</span></label>
                <select class="form-control" id="state" name="state" required>
                    <option value=""><?php echo e(old('state', isset($partyToEdit->id) ? $partyToEdit->address->state : 'Select State')); ?></option>
                    <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($state->name); ?>"><?php echo e($state->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="city">City<span class="text-danger">*</span></label>
                <select class="form-control" id="city" name="city" required>
                    <option value=""><?php echo e(old('city', isset($partyToEdit->id) ? $partyToEdit->address->city : 'Select City')); ?></option>
                </select>
            </div> 
        
            <div class="form-group">
                <label for="number">Mobile Number<span class="text-danger">*</span></label>
                <input type="text" class="form-control" id="number" name="number" value="<?php echo e(old('number', isset($partyToEdit->id) ? $partyToEdit->number : '')); ?>" required minlength="10" maxlength="10" min="6000000000" max="9999999999">
            </div>

            <div class="form-group">
                <label for="party_logo">Upload Logo<span class="text-danger">*</span></label>
                <input type="file" class="form-control" id="party_logo" name="party_logo" accept="image/*" onchange="validateImageFile(this)" <?php echo e(isset($partyToEdit->party_logo) ? '' : 'required'); ?>>
                <?php if(isset($partyToEdit->party_logo)): ?>
                    <img id="current-photo" src="<?php echo e(asset('storage/' . $partyToEdit->party_logo)); ?>" class="img-thumbnail img-placeholder" alt="Current Party Logo">
                <?php endif; ?>
            </div>
            
            <button type="submit" class="btn btn-primary butn"><?php echo e(isset($partyToEdit->id) ? 'Update' : 'Save'); ?></button>
        </form>              
    </div>

    <script>
        const candidates = <?php echo json_encode($candidates, 15, 512) ?>;
        const parties = <?php echo json_encode($parties, 15, 512) ?>;
        const states = <?php echo json_encode($states, 15, 512) ?>;
        const districts = <?php echo json_encode($districts, 15, 512) ?>;
        var inputField = document.querySelector('#number');

        inputField.onkeydown = function(event) {
            // Only allow if the e.key value is a number or if it's 'Backspace'
            if (isNaN(event.key) && event.key !== 'Backspace') {
                event.preventDefault();
            }
        };

        document.addEventListener('DOMContentLoaded', function() {
            const existingPartyNames = <?php echo json_encode($existingPartyNames, 15, 512) ?>;
            const nameInput = document.getElementById('name');

            nameInput.addEventListener('input', function() {
                const name = nameInput.value.trim().toLowerCase();
                if (existingPartyNames.map(n => n.toLowerCase()).includes(name)) {
                    alert("The party name already exists. Please use a different name");
                }
            });

            // Display the current photo if it exists
            const currentPhoto = document.getElementById('current-photo');
            if (currentPhoto && currentPhoto.src) {
                currentPhoto.style.display = 'block';
            }
        });

        function validateImageFile(input) {
            const file = input.files[0];
            const fileType = file['type'];
            const validImageTypes = ['image/jpeg', 'image/png', 'image/jpg', 'image/gif', 'image/svg+xml'];

            if (!validImageTypes.includes(fileType)) {
                alert('Please upload a valid image file (JPEG, PNG, JPG, GIF, SVG).');
                input.value = '';
            }
        }

        document.getElementById('state').addEventListener('change', function() {
            const stateName = this.value;
            const state = states.find(state => state.name === stateName);
            const stateId = state.id;
            const districtDropdown = document.getElementById('city');

            districtDropdown.innerHTML = '<option value="">Select City</option>';

            if (stateId) {
                const filteredDistricts = districts.filter(district => district.state_id == stateId);
                filteredDistricts.forEach(district => {
                    const option = document.createElement('option');
                    option.value = district.name;
                    option.textContent = district.name;
                    districtDropdown.appendChild(option);
                });
            }
        });
    </script>
</body>
</html>
<?php /**PATH /home/system27/party/resources/views/party.blade.php ENDPATH**/ ?>