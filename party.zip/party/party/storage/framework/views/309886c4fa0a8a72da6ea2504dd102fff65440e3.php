<footer class="bg-light text-center text-lg-start footer">
    <div class="text-center p-3">
        © 2024 My Laravel App:
        <a class="text-dark" href="#">mywebsite.com</a>
    </div>
</footer>
<?php /**PATH /home/system27/party/resources/views/layouts/footer.blade.php ENDPATH**/ ?>