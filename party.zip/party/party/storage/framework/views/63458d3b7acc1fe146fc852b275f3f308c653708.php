<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Votes Page</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</head>
<body>
<div class="container mt-5">
    <h1>Votes</h1>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php if(session('leading')): ?>
        <div class="alert alert-info">
            <h4>Leading</h4>
            <p><?php echo e(session('leading')->name); ?> from <?php echo e(session('leading')->party); ?> with <?php echo e(session('leading')->votes); ?> votes.</p>
            <?php if(session('leadingCandidatePercentage')): ?>
                <p>Percentage of Votes: <?php echo e(session('leadingCandidatePercentage')); ?>%</p>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('results.check')); ?>" method="POST" id="votesForm">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="party">Party</label><span class="text-danger">*</span></label>
            <select class="form-control" id="party" name="party" required>
                <option value="">Select Party</option>
                <?php $__currentLoopData = $parties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $party): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($party->name); ?>"><?php echo e($party->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group">
            <label for="state">State</label><span class="text-danger">*</span></label>
            <select class="form-control" id="state" name="state" required>
                <option value="">Select State</option>
            </select>
        </div>
        <div class="form-group">
            <label for="city">City</label><span class="text-danger">*</span></label>
            <select class="form-control" id="city" name="city" required>
                <option value="">Select City</option>
            </select>
        </div>
        <div class="form-group">
            <label for="candidate">Candidate</label></label>
            <input type="text" class="form-control" id="candidate" name="candidate" readonly>
        </div>
        <div class="form-group">
            <label for="votes">Counted votes</label><span class="text-danger">*</span></label>
            <input type="number" class="form-control" id="votes" name="votes" required min="1">
        </div>
        <button type="submit" class="btn btn-primary">Save</button>
    </form>
</div>

<script>
    const candidates = <?php echo json_encode($candidates, 15, 512) ?>;
    const states = <?php echo json_encode($states, 15, 512) ?>;
    const districts = <?php echo json_encode($districts, 15, 512) ?>;

    document.getElementById('party').addEventListener('change', function() {
        const partyName = this.value;
        const partyCandidates = candidates.filter(candidate => candidate.party === partyName);
        if (partyCandidates.length === 0) {
            alert('No candidates enrolled from this party');
        }
        const stateDropdown = document.getElementById('state');
        stateDropdown.innerHTML = '<option value="">Select State</option>';

        const uniqueStates = [...new Set(partyCandidates.map(candidate => candidate.address.state))];
        uniqueStates.forEach(state => {
            const option = document.createElement('option');
            option.value = state;
            option.textContent = state;
            stateDropdown.appendChild(option);
        });
       
        document.getElementById('city').innerHTML = '<option value="">Select City</option>';
        document.getElementById('candidate').value = '';
    });

    document.getElementById('state').addEventListener('change', function() {
        const stateName = this.value;
        const partyName = document.getElementById('party').value;
        const partyCandidates = candidates.filter(candidate => candidate.party === partyName && candidate.address.state === stateName);

        const cityDropdown = document.getElementById('city');
        cityDropdown.innerHTML = '<option value="">Select City</option>';

        const uniqueCities = [...new Set(partyCandidates.map(candidate => candidate.address.city))];
        uniqueCities.forEach(city => {
            const option = document.createElement('option');
            option.value = city;
            option.textContent = city;
            cityDropdown.appendChild(option);
        });

        document.getElementById('candidate').value = '';
    });

    document.getElementById('city').addEventListener('change', function() {
        const cityName = this.value;
        const stateName = document.getElementById('state').value;
        const partyName = document.getElementById('party').value;
        const partyCandidate = candidates.find(candidate => candidate.party === partyName && candidate.address.state === stateName && candidate.address.city === cityName);

        // if (partyCandidate) {
            document.getElementById('candidate').value = partyCandidate.name;
        // } 
    });

    var inputField = document.querySelector('#votes');
    inputField.onkeydown = function(event) {
        // Only allow if the e.key value is a number or if it's 'Backspace'
        if(isNaN(event.key) && event.key !== 'Backspace') {
            event.preventDefault();
        }
    };
</script>
</body>
</html>
<?php /**PATH /home/system27/party/resources/views/votes.blade.php ENDPATH**/ ?>