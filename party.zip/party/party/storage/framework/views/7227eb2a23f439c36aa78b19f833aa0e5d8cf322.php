<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Results Page</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

</head>
<body>
<div class="container mt-5">
    <h1>Check Results</h1>

    <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>

    <?php if(session('winner')): ?>
        <div class="alert alert-info">
            <h4>Winner</h4>
            <p><?php echo e(session('winner')->name); ?> from <?php echo e(session('winner')->party); ?> with <?php echo e(session('winner')->votes); ?> votes.</p>
        </div>
    <?php endif; ?>

        <form action="<?php echo e(route('results.check')); ?>" method="POST" >
            <?php echo csrf_field(); ?>

            <div class="form-group">
                <label for="party">Party</label><span class="text-danger">*</span></label>
                <input type="text" class="form-control" id="party" name="party" required>
            </div>

            <div class="form-group">
                <label for="candidate_id">Candidate ID</label><span class="text-danger">*</span></label>
                <input type="number" class="form-control" id="candidate_id" name="candidate_id" required min="1">
            </div>

            <div class="form-group">
                <label for="votes">Total Counted votes</label><span class="text-danger">*</span></label>
                <input type="number" class="form-control" id="votes" name="votes" required min="0">
            </div>

            <button type="submit" class="btn btn-primary">Save</button>
        </form>
    </div>

</body>
</html>
<?php /**PATH /home/system27/party/resources/views/results.blade.php ENDPATH**/ ?>